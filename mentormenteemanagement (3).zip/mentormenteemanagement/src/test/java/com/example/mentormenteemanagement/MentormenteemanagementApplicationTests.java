package com.example.mentormenteemanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MentormenteemanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
